# LinkSmart Pro 🚀

Organize seus links de forma simples, rápida e inteligente.  
Site estático pronto para deploy via **GitHub Pages**.

## Funcionalidades
- 🔗 Links gratuitos
- ⚡ Interface limpa e responsiva
- 📱 Botão para WhatsApp
- 💳 Pagamento via Pix
- 📩 Suporte por e-mail

## Como usar
1. Faça o fork ou clone do repositório
2. Ative o GitHub Pages nas configurações do repositório
3. A URL será `https://seuusuario.github.io/linksmart-pro`

---

Desenvolvido por [@augustoandrade837](mailto:augustoandrade837@gmail.com)
